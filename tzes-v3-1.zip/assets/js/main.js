/* Tzes Tattoo v3: scroll scenes, preloader, cursor and small interactions. No libraries. */
(() => {
  const doc = document.documentElement;
  const rm = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const fine = matchMedia('(hover: hover) and (pointer: fine)').matches;
  const mobile = matchMedia('(max-width: 767px)');
  const clamp = (v, a = 0, b = 1) => Math.min(b, Math.max(a, v));
  const ease = (t) => 1 - Math.pow(1 - t, 3);
  const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));

  /* ---------- preloader ---------- */
  const loader = document.querySelector('[data-loader]');
  const loaderDone = new Promise((resolve) => {
    let seen = false;
    try { seen = sessionStorage.getItem('tz-seen') === '1'; } catch (e) { /* storage blocked */ }
    if (!loader || rm || seen) { loader && loader.classList.add('is-gone'); resolve(); return; }
    const count = loader.querySelector('[data-loader-count]');
    const fill = loader.querySelector('[data-loader-fill]');
    const start = performance.now();
    let loaded = document.readyState === 'complete';
    addEventListener('load', () => { loaded = true; });
    const tick = (now) => {
      const t = now - start;
      // runs to 85% on its own, the rest waits for the page (max 3.2s)
      const target = loaded || t > 3200 ? 1 : 0.85;
      const v = Math.min(target, ease(clamp(t / 1300)) * target);
      count.textContent = Math.round(v * 100);
      fill.style.transform = `scaleX(${v})`;
      if (v >= 1) {
        loader.classList.add('is-done');
        try { sessionStorage.setItem('tz-seen', '1'); } catch (e) { /* storage blocked */ }
        setTimeout(() => { loader.classList.add('is-gone'); }, 1000);
        resolve();
      } else requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
  });

  /* ---------- split headings into words ---------- */
  $$('[data-split]').forEach((el) => {
    let i = 0;
    const walk = (node) => {
      Array.from(node.childNodes).forEach((n) => {
        if (n.nodeType === 3) {
          const frag = document.createDocumentFragment();
          n.textContent.split(/(\s+)/).forEach((part) => {
            if (!part) return;
            if (/^\s+$/.test(part)) { frag.appendChild(document.createTextNode(part)); return; }
            const w = document.createElement('span');
            w.className = 'tz-w';
            const inner = document.createElement('span');
            inner.className = 'tz-w__i';
            inner.style.setProperty('--wi', i++);
            inner.textContent = part;
            w.appendChild(inner);
            frag.appendChild(w);
          });
          n.replaceWith(frag);
        } else if (n.nodeType === 1) walk(n);
      });
    };
    walk(el);
  });

  /* ---------- scramble text for the mono tags ---------- */
  const glyphs = 'ΑΒΓΔΕΖΗΘΛΞΠΣΦΨΩ#/+01';
  const scramble = (el) => {
    if (rm || el.dataset.busy) return;
    const text = el.dataset.text || (el.dataset.text = el.textContent);
    el.dataset.busy = '1';
    let f = 0;
    const total = 18;
    const step = () => {
      const k = f / total;
      el.textContent = text.split('').map((c, i) => (c === ' ' || i / text.length < k ? c : glyphs[(Math.random() * glyphs.length) | 0])).join('');
      if (f++ < total) requestAnimationFrame(step);
      else { el.textContent = text; delete el.dataset.busy; }
    };
    step();
  };
  $$('[data-scramble]').forEach((el) => el.addEventListener('pointerenter', () => scramble(el)));

  /* ---------- reveal on view ---------- */
  $$('.tz-steps__list, .tz-faq__list').forEach((list) => Array.from(list.children).forEach((c, i) => c.style.setProperty('--ri', i)));
  const io = new IntersectionObserver((entries) => {
    entries.forEach((e) => {
      if (!e.isIntersecting) return;
      e.target.classList.add('is-in');
      $$('[data-scramble]', e.target).forEach(scramble);
      io.unobserve(e.target);
    });
  }, { rootMargin: '0px 0px -12% 0px' });
  loaderDone.then(() => {
    $$('[data-split], [data-reveal]').forEach((el) => io.observe(el));
    $$('.tz-hero [data-scramble]').forEach((el, i) => setTimeout(() => scramble(el), 300 + i * 120));
  });

  /* ---------- videos: play only while visible ---------- */
  const vids = $$('video[data-autoplay]');
  if (!rm) {
    const vio = new IntersectionObserver((entries) => entries.forEach((e) => {
      const v = e.target;
      if (e.isIntersecting) { v.preload = 'auto'; const p = v.play(); if (p) p.catch(() => {}); } else v.pause();
    }), { threshold: 0.2 });
    vids.forEach((v) => vio.observe(v));
  }

  /* ---------- header and menu ---------- */
  const header = document.querySelector('[data-header]');
  const darks = $$('[data-theme="dark"]');
  const menu = document.querySelector('[data-menu]');
  const openBtn = document.querySelector('[data-menu-open]');
  const closeBtn = document.querySelector('[data-menu-close]');
  const setMenu = (open) => {
    if (open) { menu.hidden = false; requestAnimationFrame(() => menu.classList.add('is-open')); closeBtn.focus(); }
    else { menu.classList.remove('is-open'); setTimeout(() => { menu.hidden = true; }, rm ? 0 : 700); openBtn.focus(); }
    openBtn.setAttribute('aria-expanded', String(open));
    doc.style.overflow = open ? 'hidden' : '';
  };
  openBtn && openBtn.addEventListener('click', () => setMenu(true));
  closeBtn && closeBtn.addEventListener('click', () => setMenu(false));
  addEventListener('keydown', (e) => { if (e.key === 'Escape' && menu && !menu.hidden) setMenu(false); });

  /* ---------- pointer: cursor, magnetic buttons, parallax ---------- */
  const pointer = { x: innerWidth / 2, y: innerHeight / 2, nx: 0, ny: 0 };
  addEventListener('pointermove', (e) => {
    pointer.x = e.clientX; pointer.y = e.clientY;
    pointer.nx = (e.clientX / innerWidth) * 2 - 1;
    pointer.ny = (e.clientY / innerHeight) * 2 - 1;
  }, { passive: true });

  const cursor = document.querySelector('[data-cursor-el]');
  const cursorLabel = document.querySelector('[data-cursor-label]');
  const cur = { x: -100, y: -100, rx: 0, ry: 0 };
  if (cursor && fine && !rm) {
    document.addEventListener('pointerover', (e) => {
      const lab = e.target.closest('[data-cursor]');
      const link = e.target.closest('a, button, summary');
      cursor.classList.toggle('is-label', !!lab);
      cursor.classList.toggle('is-link', !lab && !!link);
      if (lab) cursorLabel.textContent = lab.dataset.cursor;
    });
  }
  if (fine && !rm) {
    $$('[data-magnetic]').forEach((el) => {
      el.addEventListener('pointermove', (e) => {
        const r = el.getBoundingClientRect();
        el.style.setProperty('--mx', ((e.clientX - r.left - r.width / 2) * 0.22).toFixed(1) + 'px');
        el.style.setProperty('--my', ((e.clientY - r.top - r.height / 2) * 0.3).toFixed(1) + 'px');
      });
      el.addEventListener('pointerleave', () => { el.style.setProperty('--mx', '0px'); el.style.setProperty('--my', '0px'); });
    });
  }

  /* ---------- scenes ---------- */
  const scenes = $$('[data-scene]').map((el) => ({ el, name: el.dataset.scene, p: 0, target: 0, mx: 0, my: 0 }));
  const byName = (n) => scenes.find((s) => s.name === n);

  // sideways gallery: the section is as tall as the track is wide
  const works = byName('works');
  const track = document.querySelector('[data-works-track]');
  let worksDist = 0;
  const sizeWorks = () => {
    if (!works || !track) return;
    if (mobile.matches) { works.el.style.removeProperty('--works-h'); track.style.removeProperty('--x'); worksDist = 0; return; }
    worksDist = Math.max(0, track.scrollWidth - innerWidth);
    works.el.style.setProperty('--works-h', `${worksDist + innerHeight * 1.15}px`);
  };

  // stages: a frame sequence drawn on a canvas
  const stages = byName('stages');
  const canvas = document.querySelector('.tz-stages__canvas');
  const ctx = canvas && canvas.getContext('2d');
  const tabs = $$('[data-stage]');
  let frames = [], frameSet = '', lastFrame = -1, lastStage = -1;
  const loadFrames = () => {
    if (!canvas) return;
    const set = mobile.matches ? 'm' : 'd';
    if (set === frameSet) return;
    frameSet = set;
    const n = +canvas.dataset.count;
    frames = Array.from({ length: n }, (_, i) => {
      const img = new Image();
      img.decoding = 'async';
      img.src = `${canvas.dataset.frames}${set}/s-${String(i).padStart(2, '0')}.webp`;
      img.onload = () => { if (i === shown) drawFrame(shown); };
      return img;
    });
    lastFrame = -1;
  };
  const sizeCanvas = () => {
    if (!canvas) return;
    const dpr = Math.min(devicePixelRatio || 1, 2);
    canvas.width = Math.round(canvas.clientWidth * dpr);
    canvas.height = Math.round(canvas.clientHeight * dpr);
    lastFrame = -1;
  };
  const drawFrame = (i) => {
    // fall back to the nearest frame that has loaded
    let img = frames[i], k = i;
    while (k >= 0 && !(frames[k] && frames[k].complete && frames[k].naturalWidth)) k--;
    if (k < 0) return;
    img = frames[k];
    const cw = canvas.width, ch = canvas.height;
    const s = Math.max(cw / img.naturalWidth, ch / img.naturalHeight);
    const w = img.naturalWidth * s, h = img.naturalHeight * s;
    ctx.drawImage(img, (cw - w) / 2, (ch - h) / 2, w, h);
  };
  // a tap plays the sleeve to the end of that stage; nothing is tied to scrolling
  const stageSec = document.querySelector('.tz-stages');
  let shown = 0, playing = 0;
  const stageEnd = (i) => Math.round(((i + 1) / 4) * (frames.length - 1));
  const setStage = (i) => {
    if (stageSec) stageSec.dataset.active = i;
    tabs.forEach((t, k) => { t.setAttribute('aria-pressed', String(k === i)); t.style.setProperty('--tp', k <= i ? 1 : 0); });
  };
  const playStage = (i) => {
    if (!canvas || !frames.length) return;
    setStage(i);
    const from = shown, to = stageEnd(i), id = ++playing, t0 = performance.now(), dur = rm ? 0 : 650;
    const step = (now) => {
      if (id !== playing) return;
      const k = dur ? clamp((now - t0) / dur) : 1;
      shown = Math.round(from + (to - from) * ease(k));
      drawFrame(shown);
      if (k < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  };
  tabs.forEach((tab) => tab.addEventListener('click', () => playStage(+tab.dataset.stage)));

  // hero: the walk into the studio, one frame per scroll step, ending on the logo tattoo
  const walkCanvas = document.querySelector('[data-walk]');
  const walkCtx = walkCanvas && walkCanvas.getContext('2d');
  let walkFrames = [], walkSet = '', walkLast = -1;
  const loadWalk = () => {
    if (!walkCanvas) return;
    const set = mobile.matches ? 'm' : 'd';
    if (set === walkSet) return;
    walkSet = set;
    const n = +walkCanvas.dataset.count;
    const order = [n - 1, 0, ...Array.from({ length: n - 2 }, (_, i) => i + 1)];
    walkFrames = new Array(n);
    // the first and last frames first, so the page never shows an empty stage
    order.forEach((i) => {
      const img = new Image();
      img.decoding = 'async';
      img.onload = () => { if (i === walkLast || walkLast < 0) walkLast = -1; };
      img.src = `${walkCanvas.dataset.walk}${set}/w-${String(i).padStart(3, '0')}.webp`;
      walkFrames[i] = img;
    });
    walkLast = -1;
  };
  const sizeWalk = () => {
    if (!walkCanvas) return;
    const dpr = Math.min(devicePixelRatio || 1, 2);
    walkCanvas.width = Math.round(walkCanvas.clientWidth * dpr);
    walkCanvas.height = Math.round(walkCanvas.clientHeight * dpr);
    walkCtx.imageSmoothingQuality = 'high';
    walkLast = -1;
  };
  const drawWalk = (i) => {
    let k = i;
    const ok = (j) => walkFrames[j] && walkFrames[j].complete && walkFrames[j].naturalWidth;
    while (k >= 0 && !ok(k)) k--;
    if (k < 0) return false;
    const img = walkFrames[k];
    const cw = walkCanvas.width, ch = walkCanvas.height;
    // the frame sits below the header; its top rows are stretched up behind the header
    const top = Math.min(ch * 0.3, (parseFloat(getComputedStyle(walkCanvas).scrollMarginTop) || 0) * (walkCanvas.width / walkCanvas.clientWidth));
    const s = Math.max(cw / img.naturalWidth, (ch - top) / img.naturalHeight);
    const w = img.naturalWidth * s, h = img.naturalHeight * s;
    const y = top + (ch - top - h) / 2;
    walkCtx.drawImage(img, (cw - w) / 2, y, w, h);
    if (y > 0) walkCtx.drawImage(img, 0, 0, img.naturalWidth, 6, (cw - w) / 2, 0, w, y + 1);
    return k === i;
  };

  // tickers drift on their own and speed up with scrolling
  const tickers = $$('[data-ticker]').map((el, i) => ({ el, x: 0, dir: i % 2 ? -1 : 1 }));
  let lastY = scrollY, vel = 0;

  const measure = () => { sizeWorks(); loadFrames(); sizeCanvas(); loadWalk(); sizeWalk(); if (canvas && frames.length) drawFrame(shown); };
  measure();
  if (canvas && frames.length) { shown = stageEnd(0); setStage(0); }
  addEventListener('resize', measure);
  mobile.addEventListener && mobile.addEventListener('change', measure);

  const frame = () => {
    const vh = innerHeight;
    const y = scrollY;
    vel += ((y - lastY) - vel) * 0.2;
    lastY = y;

    // header state
    if (header) {
      header.classList.toggle('is-scrolled', y > 20);
      const mid = header.offsetHeight / 2;
      header.classList.toggle('is-dark', darks.some((d) => { const r = d.getBoundingClientRect(); return r.top <= mid && r.bottom >= mid; }));
    }

    // cursor follows with a small lag
    if (cursor && fine && !rm) {
      cur.x += (pointer.x - cur.x) * 0.35; cur.y += (pointer.y - cur.y) * 0.35;
      cursor.style.setProperty('--cx', cur.x.toFixed(1) + 'px');
      cursor.style.setProperty('--cy', cur.y.toFixed(1) + 'px');
    }

    scenes.forEach((s) => {
      const r = s.el.getBoundingClientRect();
      if (r.bottom < -vh || r.top > vh * 2) return;
      if (s.name === 'outro') s.target = clamp((vh - r.top) / (vh * 0.85));
      else {
        const range = s.el.offsetHeight - vh;
        s.target = range > 0 ? clamp(-r.top / range) : clamp((vh - r.top) / (vh + r.height));
      }
      s.p += (s.target - s.p) * (rm ? 1 : 0.14);
      if (Math.abs(s.target - s.p) < 0.0005) s.p = s.target;
      s.el.style.setProperty('--p', s.p.toFixed(4));
      if (!rm && fine && (s.name === 'hero' || s.name === 'apart' || s.name === 'intro')) {
        s.mx += (pointer.nx - s.mx) * 0.06; s.my += (pointer.ny - s.my) * 0.06;
        s.el.style.setProperty('--mx', s.mx.toFixed(3));
        s.el.style.setProperty('--my', s.my.toFixed(3));
      }
      if (s.name === 'apart') s.el.style.setProperty('--e', rm ? 1 : ease(clamp((s.p - 0.06) / 0.6)).toFixed(4));
      if (s.name === 'works' && track && worksDist) track.style.setProperty('--x', (-s.p * worksDist).toFixed(1) + 'px');
      if (s.name === 'hero' && walkCanvas && walkFrames.length) {
        const idx = rm ? walkFrames.length - 1 : Math.round(clamp(s.p / 0.96) * (walkFrames.length - 1));
        if (idx !== walkLast && drawWalk(idx)) walkLast = idx;
      }
      if (s.name === 'stages' && canvas && frames.length) {
        const q = clamp((s.p - 0.02) / 0.92);
        const n = frames.length;
        const idx = Math.round(q * (n - 1));
        if (idx !== lastFrame) { drawFrame(idx); lastFrame = idx; }
        const st = Math.min(3, Math.floor(q * 4));
        if (st !== lastStage) {
          s.el.dataset.active = st;
          tabs.forEach((t, i) => t.setAttribute('aria-pressed', String(i === st)));
          lastStage = st;
        }
        tabs.forEach((t, i) => t.style.setProperty('--tp', clamp(q * 4 - i).toFixed(3)));
      }
    });

    if (!rm) tickers.forEach((t) => {
      const w = t.el.scrollWidth / 3;
      t.x -= t.dir * 0.5;
      if (t.x <= -w) t.x += w;
      if (t.x > 0) t.x -= w;
      t.el.style.setProperty('--tx', t.x.toFixed(1) + 'px');
    });

    requestAnimationFrame(frame);
  };
  requestAnimationFrame(frame);

  /* ---------- gallery: style filter, viewer, tilt ---------- */
  const grid = document.querySelector('[data-gallery]');
  if (grid) {
    const chips = $$('[data-filter]');
    const items = $$('.tz-gal__item', grid);
    const setFilter = (f) => {
      if (!chips.some((c) => c.dataset.filter === f)) f = 'all';
      chips.forEach((c) => c.setAttribute('aria-pressed', String(c.dataset.filter === f)));
      items.forEach((it) => { it.hidden = f !== 'all' && it.dataset.style !== f; });
    };
    chips.forEach((c) => c.addEventListener('click', () => {
      setFilter(c.dataset.filter);
      try { history.replaceState(null, '', c.dataset.filter === 'all' ? location.pathname : `#${c.dataset.filter}`); } catch (e) { /* not allowed here */ }
    }));
    if (location.hash) setFilter(location.hash.slice(1));

    const viewer = document.querySelector('[data-viewer]');
    const vImg = viewer.querySelector('[data-viewer-img]');
    const vName = viewer.querySelector('[data-viewer-name]');
    const vStyle = viewer.querySelector('[data-viewer-style]');
    const vCount = viewer.querySelector('[data-viewer-count]');
    let list = [], at = 0, opener = null;
    const show = (i) => {
      at = (i + list.length) % list.length;
      const card = list[at];
      vImg.src = card.dataset.full;
      vImg.alt = card.querySelector('img').alt;
      vName.textContent = card.dataset.name;
      vStyle.textContent = card.dataset.label;
      vCount.textContent = `${at + 1} / ${list.length}`;
    };
    grid.addEventListener('click', (e) => {
      const card = e.target.closest('[data-open]');
      if (!card) return;
      list = items.filter((it) => !it.hidden).map((it) => it.querySelector('[data-open]'));
      opener = card;
      show(list.indexOf(card));
      viewer.showModal();
    });
    viewer.querySelector('[data-viewer-prev]').addEventListener('click', () => show(at - 1));
    viewer.querySelector('[data-viewer-next]').addEventListener('click', () => show(at + 1));
    viewer.querySelector('[data-viewer-close]').addEventListener('click', () => viewer.close());
    viewer.addEventListener('click', (e) => { if (e.target === viewer) viewer.close(); });
    viewer.addEventListener('close', () => opener && opener.focus());
    viewer.addEventListener('keydown', (e) => {
      if (e.key === 'ArrowLeft') show(at - 1);
      if (e.key === 'ArrowRight') show(at + 1);
    });
    let touchX = null;
    viewer.addEventListener('touchstart', (e) => { touchX = e.touches[0].clientX; }, { passive: true });
    viewer.addEventListener('touchend', (e) => {
      if (touchX === null) return;
      const dx = e.changedTouches[0].clientX - touchX;
      if (Math.abs(dx) > 40) show(at + (dx < 0 ? 1 : -1));
      touchX = null;
    });
  }
  if (fine && !rm) {
    $$('[data-tilt]').forEach((el) => {
      el.addEventListener('pointermove', (e) => {
        const r = el.getBoundingClientRect();
        el.style.setProperty('--ry', (((e.clientX - r.left) / r.width - 0.5) * 10).toFixed(2) + 'deg');
        el.style.setProperty('--rx', (((e.clientY - r.top) / r.height - 0.5) * -10).toFixed(2) + 'deg');
      });
      el.addEventListener('pointerleave', () => { el.style.setProperty('--rx', '0deg'); el.style.setProperty('--ry', '0deg'); });
    });
  }

  /* ---------- contact form: check fields, then show the thank-you note ---------- */
  const form = document.querySelector('[data-form]');
  if (form) {
    const checks = {
      name: (v) => v.trim().length > 1,
      email: (v) => /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v.trim()),
      phone: (v) => v.replace(/\D/g, '').length >= 10,
      message: (v) => v.trim().length > 4,
      consent: (v, el) => el.checked,
    };
    const check = (el) => {
      const ok = checks[el.name](el.value, el);
      const err = document.getElementById(`${el.id}-err`);
      el.setAttribute('aria-invalid', String(!ok));
      err.textContent = ok ? '' : err.dataset.err;
      return ok;
    };
    const fields = Object.keys(checks).map((n) => form.elements[n]);
    fields.forEach((el) => el.addEventListener(el.type === 'checkbox' ? 'change' : 'blur', () => { if (el.value || el.checked || el.hasAttribute('aria-invalid')) check(el); }));
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      const bad = fields.filter((el) => !check(el));
      if (bad.length) { bad[0].focus(); return; }
      // no mail endpoint yet: the real site sends this to the studio (see MANIFEST)
      const done = document.querySelector('[data-form-done]');
      form.hidden = true;
      done.hidden = false;
      done.focus();
    });
  }

  /* ---------- the mascot: a few quiet easter eggs ---------- */
  const peek = document.querySelector('[data-peek]');
  if (peek) {
    let timer = 0, done = false;
    try { done = sessionStorage.getItem('tz-peek') === '1'; } catch (e) { /* storage blocked */ }
    const hide = () => { peek.classList.remove('is-out', 'is-wink'); clearTimeout(timer); timer = setTimeout(() => { peek.hidden = true; }, 600); };
    const show = (wink) => {
      clearTimeout(timer);
      peek.hidden = false;
      requestAnimationFrame(() => requestAnimationFrame(() => peek.classList.add('is-out')));
      peek.classList.toggle('is-wink', !!wink);
      timer = setTimeout(hide, wink ? 2200 : 5000);
    };
    peek.addEventListener('click', () => { peek.classList.add('is-wink'); clearTimeout(timer); timer = setTimeout(hide, 1200); });
    // once per visit he peeks in when you reach the bottom of a page
    const foot = document.querySelector('.tz-footer');
    if (foot && !done) {
      const fio = new IntersectionObserver((en) => {
        if (!en.some((e) => e.isIntersecting)) return;
        fio.disconnect();
        try { sessionStorage.setItem('tz-peek', '1'); } catch (e) { /* storage blocked */ }
        show(false);
      }, { threshold: 0.6 });
      fio.observe(foot);
    }
    // type "tzes" anywhere and he winks
    let typed = '';
    addEventListener('keydown', (e) => {
      if (e.target.closest && e.target.closest('input, textarea, select')) return;
      typed = (typed + (e.key || '')).slice(-4).toLowerCase();
      if (typed === 'tzes') show(true);
    });
  }
  try { console.log('%c TZES TATTOO %c Ηράκλειο. Γράψε "tzes" στη σελίδα.', 'background:#9f0102;color:#fff;font-weight:700;padding:2px 6px', 'color:#9f0102'); } catch (e) { /* no console */ }
})();
