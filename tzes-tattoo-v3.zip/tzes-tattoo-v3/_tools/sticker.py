# Puts a flash cut-out on a paper "sticker" silhouette so it can sit in front of type.
import sys, numpy as np
from PIL import Image, ImageFilter, ImageDraw
src, out, pad = sys.argv[1], sys.argv[2], int(sys.argv[3])
im = Image.open(src).convert('RGBA')
w, h = im.size
canvas = Image.new('RGBA', (w + 2*pad, h + 2*pad), (0, 0, 0, 0))
canvas.paste(im, (pad, pad), im)
a = canvas.getchannel('A').point(lambda v: 255 if v > 40 else 0)
m = a.filter(ImageFilter.MaxFilter(31)).filter(ImageFilter.MaxFilter(31))
# fill holes: flood the outside from a corner, everything not reached is inside
mm = m.copy(); ImageDraw.floodfill(mm, (0, 0), 128)
inside = mm.point(lambda v: 0 if v == 128 else 255)
inside = inside.filter(ImageFilter.MinFilter(15)).filter(ImageFilter.GaussianBlur(6)).point(lambda v: 255 if v > 128 else 0).filter(ImageFilter.GaussianBlur(1.2))
# drop tiny islands (like the artist's corner signature): keep parts bigger than 3% of the largest
small = inside.resize((inside.width // 8, inside.height // 8)).point(lambda v: 255 if v > 128 else 0)
arr = np.array(small) > 0
lab = np.zeros(arr.shape, int); sizes = []
for yy in range(arr.shape[0]):
    for xx in range(arr.shape[1]):
        if arr[yy, xx] and not lab[yy, xx]:
            stack = [(yy, xx)]; lab[yy, xx] = len(sizes) + 1; n = 0
            while stack:
                cy, cx = stack.pop(); n += 1
                for dy, dx in ((1,0),(-1,0),(0,1),(0,-1)):
                    ny, nx = cy + dy, cx + dx
                    if 0 <= ny < arr.shape[0] and 0 <= nx < arr.shape[1] and arr[ny, nx] and not lab[ny, nx]:
                        lab[ny, nx] = len(sizes) + 1; stack.append((ny, nx))
            sizes.append(n)
keep = np.isin(lab, [i + 1 for i, n in enumerate(sizes) if n >= 0.03 * max(sizes)])
keepm = Image.fromarray((keep * 255).astype(np.uint8)).resize(inside.size).filter(ImageFilter.MaxFilter(9))
inside = Image.fromarray(np.minimum(np.array(inside), np.array(keepm)))
ca = np.array(canvas); ca[..., 3] = np.minimum(ca[..., 3], np.array(keepm)); canvas = Image.fromarray(ca)
paper = Image.new('RGBA', canvas.size, (240, 236, 229, 255)); paper.putalpha(inside)
# thin ink keyline around the sticker
edge = inside.filter(ImageFilter.MaxFilter(5))
key = Image.new('RGBA', canvas.size, (13, 12, 12, 255)); key.putalpha(edge)
outimg = Image.alpha_composite(Image.new('RGBA', canvas.size, (0,0,0,0)), key)
outimg = Image.alpha_composite(outimg, paper)
outimg = Image.alpha_composite(outimg, canvas)
for wd in (420, 840):
    c = outimg.copy(); c.thumbnail((wd, wd*2)); c.save(out + f'-{wd}.webp', 'WEBP', quality=86, method=6)
print(outimg.size)
