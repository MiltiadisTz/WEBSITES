import sys, numpy as np
from PIL import Image
src, out = sys.argv[1], sys.argv[2]
im = Image.open(src).convert('RGB'); w,h = im.size
a = np.asarray(im).astype(np.float32)/255
x0,x1,y0,y1 = int(w*.075),int(w*.925),int(h*.055),int(h*.945)
a = a[y0:y1,x0:x1]
paper = np.median(np.concatenate([a[:20,:].reshape(-1,3),a[-20:,:].reshape(-1,3)]),axis=0)
al = np.max((paper - a)/np.maximum(paper,1e-3),axis=2)
al = np.clip((al-0.22)/0.78,0,1)
al = np.clip(al*1.25,0,1)
safe = np.maximum(al,1e-3)[...,None]
col = np.clip((a - paper*(1-al[...,None]))/safe,0,1)
col = np.where(al[...,None]>0.02, col, 0)
rgba = np.dstack([col, al])
img = Image.fromarray((rgba*255).astype(np.uint8),'RGBA')
bb = img.getchannel('A').point(lambda v: 255 if v>30 else 0).getbbox()
img = img.crop(bb)
img.save(out, 'WEBP', quality=86, method=6)
print(out, img.size, paper)
# negative version for dark sections: neutral ink turns bone white, red stays
c = np.asarray(img).astype(np.float32)/255
rgb, A = c[...,:3], c[...,3:]
sat = rgb.max(2)-rgb.min(2)
bone = np.array([0.94,0.91,0.87])
mix = np.clip((sat-0.12)/0.2,0,1)[...,None]
neg = rgb*mix + bone*(1-mix)
Image.fromarray((np.dstack([neg,A])*255).astype(np.uint8),'RGBA').save(out.replace('.webp','-neg.webp'),'WEBP',quality=86,method=6)
