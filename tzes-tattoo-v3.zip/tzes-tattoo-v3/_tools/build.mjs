// Builds every page in Greek (/) and English (/en/) from the dictionaries in _tools/content.
// Usage: node _tools/build.mjs [--preview]
// --preview also writes the claude.ai preview: _entry.html (Home) and p-*.html (inner pages), Greek only.
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { innerPages } from './inner.mjs';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const read = (p) => JSON.parse(readFileSync(join(root, p), 'utf8'));
const SITE = 'https://www.tzestattoo.gr/';

const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
// *text* marks the part of a headline set in red
const mark = (s, cls) => esc(s).replace(/\*(.+?)\*/g, `<span class="${cls}">$1</span>`);
const plain = (s) => s.replace(/\*/g, '');
const icon = (b, id, cls = 'tz-icon') => `<svg class="${cls}" aria-hidden="true" focusable="false"><use href="${b}assets/img/sprite.svg#${id}"></use></svg>`;

const KEYS = ['home', 'gallery', 'about', 'contact', 'privacy', 'notfound'];
const outFile = (t, key) => (t.pages[key].endsWith('.html') ? t.pages[key] : `${t.pages[key]}index.html`);

function page(t, alt, key = 'home', links = null) {
  // relative base from the file to the site root; the 404 pages use the root itself because they answer any URL
  const depth = outFile(t, key).split('/').length - 1;
  const b = links ? '' : key === 'notfound' ? '/' : '../'.repeat(depth);
  const href = links ? (p) => links(p) : (p) => (b + t.pages[p]) || './';
  const homeHref = href('home');
  const altHref = links ? links('home') : (b + alt.pages[key === 'notfound' ? 'home' : key]) || './';
  const ph = (s) => `<span class="tz-ph">${esc(s)}</span>`;
  const cur = (p) => (p === key ? ' aria-current="page"' : '');

  const header = `
<a class="tz-skip" href="#main">${esc(t.ui.skip)}</a>
<header class="tz-header" data-header>
  <div class="tz-header__inner">
    <a class="tz-logo" href="${homeHref}" aria-label="${esc(t.ui.logoLabel)}" data-magnetic>
      <span class="tz-logo__mark" aria-hidden="true"></span>
      <span class="tz-logo__word">TZES</span>
    </a>
    <nav class="tz-nav" aria-label="${esc(t.ui.navLabel)}">
      <ul class="tz-nav__list">
        ${t.nav.map((n) => `<li><a class="tz-nav__link" href="${href(n.page)}"${cur(n.page)} data-scramble>${esc(n.label)}</a></li>`).join('')}
      </ul>
    </nav>
    <div class="tz-header__end">
      <a class="tz-lang" href="${altHref}" hreflang="${t.other.lang}" lang="${t.other.lang}" aria-label="${esc(t.other.name)}">${t.other.label}</a>
      <a class="tz-btn tz-btn--red tz-btn--sm tz-header__cta" href="${href(t.cta.page)}" data-magnetic><span>${esc(t.cta.label)}</span>${icon(b, 'arrow-up-right')}</a>
      <button class="tz-burger" type="button" aria-expanded="false" aria-controls="tz-menu" data-menu-open>
        <span class="tz-burger__lines" aria-hidden="true"></span><span class="tz-sr-only">${esc(t.ui.menuOpen)}</span>
      </button>
    </div>
  </div>
</header>
<div class="tz-menu" id="tz-menu" data-menu hidden>
  <div class="tz-menu__inner">
    <button class="tz-menu__close" type="button" data-menu-close>${icon(b, 'x')}<span class="tz-sr-only">${esc(t.ui.menuClose)}</span></button>
    <ul class="tz-menu__list">
      <li><a class="tz-menu__link" href="${homeHref}">${esc(t.footer.home)}</a></li>
      ${t.nav.map((n) => `<li><a class="tz-menu__link" href="${href(n.page)}"${cur(n.page)}>${esc(n.label)}</a></li>`).join('')}
    </ul>
    <a class="tz-btn tz-btn--red" href="${href(t.cta.page)}"><span>${esc(t.cta.label)}</span>${icon(b, 'arrow-up-right')}</a>
    <a class="tz-menu__lang" href="${altHref}" hreflang="${t.other.lang}" lang="${t.other.lang}">${esc(t.other.name)}</a>
  </div>
</div>`;

  const h = t.hero;
  const hero = `
<section class="tz-hero" data-scene="hero" aria-labelledby="tz-hero-title">
  <div class="tz-hero__stage" data-hero>
    <span class="tz-hero__glow" aria-hidden="true"></span>
    <p class="tz-hero__word" aria-hidden="true">${esc(h.word)}</p>
    <canvas class="tz-hero__ink" aria-hidden="true" data-ink></canvas>
    <div class="tz-hero__mark" aria-hidden="true"><span class="tz-hero__sigil"></span></div>
    <canvas class="tz-hero__dots" aria-hidden="true" data-dots="${b}assets/img/logo-mark.svg"></canvas>
    <p class="tz-hero__word tz-hero__word--outline" aria-hidden="true">${esc(h.word)}</p>
    <span class="tz-tag tz-tag--ghost tz-hero__tag" data-scramble aria-hidden="true">${esc(h.tagPlace)}</span>
    <p class="tz-hero__hint" aria-hidden="true">${esc(h.hint)}</p>
    <div class="tz-hero__copy">
      <h1 class="tz-hero__title" id="tz-hero-title" data-split>${mark(h.title, 'tz-red')}</h1>
      <div class="tz-hero__actions">
        <a class="tz-btn tz-btn--red" href="${href(t.cta.page)}" data-magnetic><span>${esc(t.cta.label)}</span>${icon(b, 'arrow-up-right')}</a>
      </div>
    </div>
    <figure class="tz-hero__video tz-cut">
      <video class="tz-hero__media" muted loop playsinline preload="none" poster="${b}assets/img/works/studio-2.webp" aria-label="${esc(h.video)}" data-autoplay>
        <source src="${b}assets/video/story.webm" type="video/webm">
        <source src="${b}assets/video/story.mp4" type="video/mp4">
      </video>
      <figcaption class="tz-hero__live"><span class="tz-live-dot" aria-hidden="true"></span>${esc(h.videoLabel)}</figcaption>
    </figure>
    <p class="tz-hero__scroll" aria-hidden="true"><span>${esc(t.ui.scroll)}</span>${icon(b, 'arrow-down')}</p>
  </div>
</section>`;

  const s = t.spec;
  const spec = `
<section class="tz-spec" aria-labelledby="tz-spec-title">
  <div class="tz-spec__card tz-cut tz-cut--lg" data-reveal>
    <div class="tz-spec__copy">
      <span class="tz-tag tz-tag--dark" data-scramble>${esc(s.tag)}</span>
      <h2 class="tz-spec__title" id="tz-spec-title">${mark(s.title, 'tz-hl')}</h2>
      <p class="tz-spec__text">${esc(s.text)}</p>
    </div>
    <div class="tz-spec__media">
      <div class="tz-spec__frame tz-cut">
        <video class="tz-spec__video" muted loop playsinline preload="none" poster="${b}assets/img/works/studio-13.webp" aria-label="${esc(h.video)}" data-autoplay>
          <source src="${b}assets/video/story.webm" type="video/webm">
          <source src="${b}assets/video/story.mp4" type="video/mp4">
        </video>
      </div>
      <p class="tz-spec__side" aria-hidden="true">${esc(s.side)}</p>
    </div>
  </div>
</section>`;

  const band = (items, cls) => {
    const run = items.map((x) => `<span class="tz-ticker__item">${esc(x)}</span><span class="tz-ticker__sep" aria-hidden="true"></span>`).join('');
    return `<div class="tz-ticker__band ${cls}" aria-hidden="true"><div class="tz-ticker__track" data-ticker>${run}${run}${run}</div></div>`;
  };
  const ticker = `
<div class="tz-ticker">
  ${band(t.ticker.styles, 'tz-ticker__band--red')}
</div>`;

  const st = t.stages;
  const stages = `
<section class="tz-stages" data-scene="stages" aria-labelledby="tz-stages-title">
  <div class="tz-stages__stage">
    <div class="tz-stages__head">
      <h2 class="tz-h2 tz-stages__title" id="tz-stages-title" data-split>${mark(st.title, 'tz-red')}</h2>
      <p class="tz-stages__text">${esc(st.text)}</p>
    </div>
    <div class="tz-stages__frame tz-cut tz-cut--lg">
      <canvas class="tz-stages__canvas" width="1600" height="900" role="img" aria-label="${esc(st.alt)}" data-frames="${b}assets/img/frames/" data-count="48"></canvas>
      <span class="tz-stages__corner tz-stages__corner--tl" aria-hidden="true"></span>
      <span class="tz-stages__corner tz-stages__corner--br" aria-hidden="true"></span>
      ${st.tabs.map((x, i) => `<span class="tz-tag tz-tag--pin tz-stages__pin tz-stages__pin--${i}" data-pin="${i}" aria-hidden="true">${esc(x.tag)}</span>`).join('')}
    </div>
    <div class="tz-stages__tabs" role="group" aria-label="${esc(plain(st.title))}">
      ${st.tabs.map((x, i) => `<button class="tz-stages__tab tz-cut" type="button" data-stage="${i}" aria-pressed="${i === 0}">
        <span class="tz-stages__name">${esc(x.name)}</span><span class="tz-stages__desc">${esc(x.text)}</span><span class="tz-stages__bar" aria-hidden="true"></span>
      </button>`).join('')}
    </div>
  </div>
</section>`;

  const w = t.works;
  const works = `
<section class="tz-works" data-scene="works" data-theme="dark" aria-labelledby="tz-works-title">
  <div class="tz-works__stage">
    <div class="tz-works__head">
      <h2 class="tz-h2 tz-works__title" id="tz-works-title" data-split>${mark(w.title, 'tz-red')}</h2>
      <p class="tz-works__text">${esc(w.text)}</p>
      <a class="tz-btn tz-btn--line tz-btn--light tz-btn--sm" href="${href(w.more.page)}" data-magnetic><span>${esc(w.more.label)}</span>${icon(b, 'arrow-right')}</a>
    </div>
    <ul class="tz-works__track" data-works-track>
      ${w.items.map((x) => `<li class="tz-works__item">
        <a class="tz-works__card" href="${href('gallery')}" data-cursor="${esc(t.ui.view)}">
          <span class="tz-works__frame tz-cut"><img class="tz-works__img" src="${b}assets/img/works/${x.img}-540.webp" srcset="${b}assets/img/works/${x.img}-540.webp 540w, ${b}assets/img/works/${x.img}-1080.webp 1080w" sizes="(max-width: 767px) 74vw, 40vh" width="540" height="960" alt="${esc(x.alt)}" loading="lazy" decoding="async"></span>
          <span class="tz-works__style">${esc(x.style)}</span>
        </a>
      </li>`).join('')}
    </ul>
    <div class="tz-works__progress" aria-hidden="true"><span class="tz-works__fill"></span></div>
  </div>
</section>`;

  const a = t.apart;
  const apart = `
<section class="tz-apart" data-scene="apart" aria-labelledby="tz-apart-title">
  <div class="tz-apart__stage">
    <span class="tz-slash tz-slash--c" aria-hidden="true"></span>
    <div class="tz-apart__copy">
      <h2 class="tz-apart__title" id="tz-apart-title">${mark(a.title, 'tz-red')}</h2>
      <p class="tz-apart__text">${esc(a.text)}</p>
    </div>
    <ul class="tz-apart__pieces">
      ${a.pieces.map((x) => `<li class="tz-apart__piece tz-apart__piece--${x.img}">
        <a class="tz-apart__link" href="${href('gallery')}#${x.slug}" data-cursor="${esc(t.ui.view)}">
          <img class="tz-apart__img" src="${b}assets/img/cut/${x.img}-sticker-420.webp" width="420" height="600" alt="" loading="lazy" decoding="async">
          <span class="tz-tag tz-tag--pin tz-apart__tag">${esc(x.style)}</span>
        </a>
      </li>`).join('')}
    </ul>
  </div>
</section>`;

  const tr = t.trace;
  const trace = `
<section class="tz-trace" data-scene="trace" data-theme="dark" aria-labelledby="tz-trace-title">
  <div class="tz-trace__stage">
    <span class="tz-cross tz-cross--1" aria-hidden="true"></span><span class="tz-cross tz-cross--3" aria-hidden="true"></span>
    <h2 class="tz-trace__title" id="tz-trace-title">${mark(tr.title, 'tz-red-soft')}</h2>
    <ul class="tz-trace__cards">
      ${tr.cards.map((x, i) => `<li class="tz-trace__card tz-trace__card--${i}"><img class="tz-trace__img" src="${b}assets/img/works/${x.img}.webp" width="360" height="640" alt="${esc(x.alt)}" loading="lazy" decoding="async"></li>`).join('')}
    </ul>
    <p class="tz-trace__text">${esc(tr.text)}</p>
  </div>
</section>`;

  const sp = t.steps;
  const steps = `
<section class="tz-steps" aria-labelledby="tz-steps-title">
  <div class="tz-wrap">
    <div class="tz-steps__head">
      <h2 class="tz-h2" id="tz-steps-title" data-split>${mark(sp.title, 'tz-red')}</h2>
      <p class="tz-steps__text">${esc(sp.text)}</p>
    </div>
    <ol class="tz-steps__list">
      ${sp.items.map((x) => `<li class="tz-steps__item tz-cut" data-reveal>
        <span class="tz-steps__icon">${icon(b, x.icon)}</span>
        <h3 class="tz-steps__title">${esc(x.title)}</h3>
        <p class="tz-steps__desc">${esc(x.text)}</p>
      </li>`).join('')}
    </ol>
    <div class="tz-care" data-reveal>
      <h3 class="tz-care__title">${esc(sp.careTitle)}</h3>
      <ul class="tz-care__list">
        ${sp.care.map((x) => `<li class="tz-care__item">${icon(b, x.icon)}<span>${esc(x.text)}</span></li>`).join('')}
      </ul>
    </div>
  </div>
</section>`;

  const f = t.faq;
  const faq = `
<section class="tz-faq" data-theme="dark" aria-labelledby="tz-faq-title">
  <div class="tz-wrap tz-faq__grid">
    <div class="tz-faq__side">
      <h2 class="tz-h2" id="tz-faq-title" data-split>${mark(f.title, 'tz-red-soft')}</h2>
      <p class="tz-faq__text">${esc(f.text)}</p>
      <figure class="tz-quote tz-cut">
        ${icon(b, 'quotes', 'tz-quote__icon')}
        <blockquote class="tz-quote__text">${ph(f.quote)}</blockquote>
        <figcaption class="tz-quote__who">${ph(f.who)}</figcaption>
      </figure>
    </div>
    <div class="tz-faq__list">
      ${f.items.map((x) => `<details class="tz-faq__item tz-cut">
        <summary class="tz-faq__q"><span>${esc(x.q)}</span>${icon(b, 'plus', 'tz-faq__plus')}</summary>
        <div class="tz-faq__a">${x.a ? `<p>${esc(x.a)}</p>` : ''}${x.ph ? `<p>${ph(x.ph)}</p>` : ''}</div>
      </details>`).join('')}
    </div>
  </div>
</section>`;

  const o = t.outro, c = t.contact;
  const outro = `
<section class="tz-outro" data-scene="outro" aria-labelledby="tz-outro-title">
  <div class="tz-outro__stage">
    <span class="tz-slash tz-slash--d" aria-hidden="true"></span>
    <span class="tz-slash tz-slash--e" aria-hidden="true"></span>
    <div class="tz-outro__panel tz-cut tz-cut--lg">
      <div class="tz-outro__info">
        <h2 class="tz-outro__lines" id="tz-outro-title">${mark(o.lines, 'tz-red')}</h2>
        <dl class="tz-outro__table">
          <div><dt>${esc(o.table.address)}</dt><dd><a href="${c.mapsUrl}" rel="noopener" target="_blank">${esc(c.street)}, ${esc(c.city)}</a></dd></div>
          <div><dt>${esc(o.table.hours)}</dt><dd>${esc(c.hoursShort)}</dd></div>
          <div><dt>${esc(o.table.phone)}</dt><dd><a href="${c.phoneHref}">${esc(c.phone)}</a></dd></div>
          <div><dt>${esc(o.table.social)}</dt><dd><a href="${c.instagramHref}" rel="noopener" target="_blank">${esc(c.instagram)}</a></dd></div>
        </dl>
      </div>
      <img class="tz-outro__art" src="${b}assets/img/cut/labrys-neg-840.webp" width="840" height="1183" alt="" loading="lazy" decoding="async">
      <p class="tz-outro__word" aria-hidden="true">TZES</p>
    </div>
    <div class="tz-outro__cta">
      <p class="tz-outro__text">${esc(o.text)}</p>
      <div class="tz-hero__actions">
        <a class="tz-btn tz-btn--red" href="${href(t.cta.page)}" data-magnetic><span>${esc(t.cta.label)}</span>${icon(b, 'arrow-up-right')}</a>
        <a class="tz-btn tz-btn--line" href="${o.secondary.href}" rel="noopener" target="_blank" data-magnetic>${icon(b, 'instagram-logo')}<span>${esc(o.secondary.label)}</span></a>
      </div>
    </div>
  </div>
</section>`;

  const footer = `
<footer class="tz-footer" data-theme="dark">
  <div class="tz-wrap tz-footer__grid">
    <div class="tz-footer__brand">
      <a class="tz-logo tz-logo--light" href="${homeHref}" aria-label="${esc(t.ui.logoLabel)}"><span class="tz-logo__mark" aria-hidden="true"></span><span class="tz-logo__word">TZES</span></a>
      <p class="tz-footer__line">${esc(t.footer.line)}</p>
    </div>
    <nav class="tz-footer__nav" aria-label="${esc(t.ui.footerLabel)}">
      <ul>
        <li><a href="${homeHref}">${esc(t.footer.home)}</a></li>
        ${t.nav.map((n) => `<li><a href="${href(n.page)}">${esc(n.label)}</a></li>`).join('')}
      </ul>
    </nav>
    <div class="tz-footer__contact">
      <a href="${c.phoneHref}">${esc(c.phone)}</a>
      <a href="mailto:${c.email}">${esc(c.email)}</a>
      <span>${esc(c.street)}, ${esc(c.city)}</span>
    </div>
    <ul class="tz-footer__social" aria-label="${esc(t.ui.socialLabel)}">
      ${c.socials.map((x) => `<li><a class="tz-footer__icon" href="${x.href}" rel="noopener" target="_blank" aria-label="${esc(x.label)}">${icon(b, x.icon)}</a></li>`).join('')}
    </ul>
  </div>
  <div class="tz-wrap tz-footer__legal">
    <span>${esc(t.footer.copyright)}</span>
    <a href="${href('privacy')}">${esc(t.footer.privacy)}</a>
  </div>
</footer>`;

  const loader = `
<div class="tz-loader" data-loader aria-hidden="true">
  <span class="tz-loader__mark"></span>
  <span class="tz-loader__word">TZES TATTOO</span>
  <span class="tz-loader__count" data-loader-count>0</span>
  <span class="tz-loader__bar"><span class="tz-loader__fill" data-loader-fill></span></span>
  <span class="tz-loader__place">${esc(h.tagPlace)}</span>
</div>
<div class="tz-cursor" data-cursor-el aria-hidden="true"><span class="tz-cursor__dot"></span><span class="tz-cursor__ring"><span class="tz-cursor__label" data-cursor-label></span></span></div>`;

  // closing band shared by the inner pages
  const ctaBand = (x, art) => `
<section class="tz-band" aria-labelledby="tz-band-title">
  <div class="tz-band__panel tz-cut tz-cut--lg">
    <div class="tz-band__copy">
      <h2 class="tz-band__title" id="tz-band-title">${mark(x.title, 'tz-red-soft')}</h2>
      <p class="tz-band__text">${esc(x.text)}</p>
      <a class="tz-btn tz-btn--red" href="${href(x.button.page)}" data-magnetic><span>${esc(x.button.label)}</span>${icon(b, 'arrow-up-right')}</a>
    </div>
    <img class="tz-band__art" src="${b}assets/img/cut/${art}-sticker-420.webp" width="420" height="600" alt="" loading="lazy" decoding="async">
    <p class="tz-band__word" aria-hidden="true">TZES</p>
  </div>
</section>`;
  const inner = innerPages({ t, b, href, ph, icon: (id, cls) => icon(b, id, cls), band: ctaBand, ticker });
  const main = key === 'home' ? [hero, ticker, stages, works, apart, trace, outro].join('\n') : key === 'contact' ? inner[key]() + faq : inner[key]();
  const meta = key === 'home' ? t.meta : t.metaPages[key];
  const path = (x) => x.pages[key === 'notfound' ? 'home' : key];
  const url = SITE + path(t);
  return `<!doctype html>
<html lang="${t.lang}">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>${esc(meta.title)}</title>
<meta name="description" content="${esc(meta.description)}">
${key === 'notfound' ? '<meta name="robots" content="noindex">' : `<link rel="canonical" href="${url}">
<link rel="alternate" hreflang="${t.lang}" href="${url}">
<link rel="alternate" hreflang="${alt.lang}" href="${SITE + path(alt)}">
<link rel="alternate" hreflang="x-default" href="${SITE + (t.lang === 'el' ? path(t) : path(alt))}">`}
<meta property="og:type" content="website">
<meta property="og:locale" content="${t.locale}">
<meta property="og:title" content="${esc(meta.title)}">
<meta property="og:description" content="${esc(meta.description)}">
<meta property="og:url" content="${url}">
<meta name="theme-color" content="#0d0c0c">
<link rel="icon" href="${b}favicon.svg" type="image/svg+xml">
<link rel="preload" href="${b}assets/fonts/tz-flex-${t.lang === 'el' ? 'greek' : 'latin'}.woff2" as="font" type="font/woff2" crossorigin>
<link rel="stylesheet" href="${b}assets/css/tokens.css">
<link rel="stylesheet" href="${b}assets/css/base.css">
<link rel="stylesheet" href="${b}assets/css/components.css">
<link rel="stylesheet" href="${b}assets/css/pages.css">
<script>document.documentElement.classList.add('tz-js');</script>
<script src="${b}assets/js/main.js" defer></script>
<script type="application/ld+json">${JSON.stringify({ '@context': 'https://schema.org', '@type': 'TattooParlor', name: 'Tzes Tattoo', url: SITE, telephone: c.phone, email: c.email, address: { '@type': 'PostalAddress', streetAddress: c.street, addressLocality: t.lang === 'el' ? 'Ηράκλειο' : 'Heraklion', postalCode: '712 02', addressCountry: 'GR' }, sameAs: c.socials.map((x) => x.href) })}</script>
</head>
<body class="tz-body">
${loader}
${header}
<main id="main" class="tz-main--${key}">
${main}
</main>
${footer}
</body>
</html>
`;
}

// Preview for claude.ai: linked CSS and JS do not load there, so CSS (fonts and small images as data URIs),
// JS and the icon sprite go inline; photos, frames and video are published next to the page.
function preview(html, isEntry) {
  const dataUri = (rel) => {
    const file = join(root, 'assets', rel.replace(/^\.\.\//, ''));
    const type = { woff2: 'font/woff2', svg: 'image/svg+xml', webp: 'image/webp' }[file.split('.').pop()];
    return `data:${type};base64,${readFileSync(file).toString('base64')}`;
  };
  const css = ['tokens', 'base', 'components', 'pages'].map((n) => readFileSync(join(root, `assets/css/${n}.css`), 'utf8')).join('\n')
    .replace(/url\("(\.\.\/[^"]+)"\)/g, (_, rel) => `url("${dataUri(rel)}")`);
  const js = readFileSync(join(root, 'assets/js/main.js'), 'utf8');
  const sprite = readFileSync(join(root, 'assets/img/sprite.svg'), 'utf8').replace(/<metadata>[\s\S]*?<\/metadata>/, '')
    .replace('<svg ', '<svg class="tz-sr-only" aria-hidden="true" ');
  const head = html.match(/<head>([\s\S]*?)<\/head>/)[1]
    .replace(/<meta charset[^>]*>\s*/, '').replace(/<meta name="viewport"[^>]*>\s*/, '')
    .replace(/<link rel="(stylesheet|preload|icon)"[^>]*>\s*/g, '')
    .replace(/<script src[^>]*><\/script>\s*/, '');
  const body = html.match(/<body[^>]*>([\s\S]*?)<\/body>/)[1].replace(/assets\/img\/sprite\.svg#/g, '#');
  const doc = `${head.replace(/<title>[^<]*<\/title>/, isEntry ? '<title>Tzes Tattoo Interactive</title>' : '$&')}<style>${css}</style>\n<div class="tz-body" lang="el">${sprite}${body}</div>\n<script>${js}</script>\n`;
  return isEntry ? doc : `<!doctype html>\n<html lang="el">\n<head>\n<meta charset="utf-8">\n<meta name="viewport" content="width=device-width, initial-scale=1">\n<script>document.documentElement.classList.add('tz-js');</script>\n${doc.replace('<div class="tz-body" lang="el">', '</head>\n<body class="tz-body-wrap">\n<div class="tz-body" lang="el">')}</body>\n</html>\n`;
}

const dict = { el: read('_tools/content/el.json'), en: read('_tools/content/en.json') };
for (const lang of ['el', 'en']) {
  const t = dict[lang], alt = dict[lang === 'el' ? 'en' : 'el'];
  for (const key of KEYS) {
    const out = join(root, outFile(t, key));
    mkdirSync(dirname(out), { recursive: true });
    writeFileSync(out, page(t, alt, key));
  }
  console.log('built', lang, KEYS.length, 'pages');
}

if (process.argv.includes('--preview')) {
  // flat file names, because the preview serves every page from one folder
  const t = dict.el;
  const file = (p) => (p === 'home' ? '_entry.html' : `p-${p}.html`);
  const links = (p) => (p === 'home' ? './' : file(p));
  for (const key of KEYS) {
    const html = preview(page(t, dict.en, key, links), key === 'home');
    writeFileSync(join(root, file(key)), html);
  }
  console.log('built preview');
}
