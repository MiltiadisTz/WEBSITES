// Draws the "skin print" texture: fingerprint-like contour lines, the tattoo version of a topo map.
import { writeFileSync } from 'node:fs';
const W = 1600, H = 1000;
let seed = 7;
const rnd = () => ((seed = (seed * 16807) % 2147483647) / 2147483647);
const centers = [[260, 240], [1180, 180], [820, 720], [1480, 820], [120, 900]];
const noise = (a, k, ph) => Math.sin(a * 3 + ph) * 0.06 + Math.sin(a * 5 + ph * 2) * 0.035 + Math.sin(a * 9 + ph * 3 + k) * 0.015;
let paths = '';
for (const [cx, cy] of centers) {
  const ph = rnd() * 6, rot = rnd() * Math.PI, ecc = 0.62 + rnd() * 0.25;
  for (let k = 1; k < 26; k++) {
    const r = 16 * k + rnd() * 4;
    const pts = [];
    for (let i = 0; i < 40; i++) {
      const a = (i / 40) * Math.PI * 2;
      const rr = r * (1 + noise(a, k * 0.4, ph + k * 0.05));
      const x0 = Math.cos(a) * rr, y0 = Math.sin(a) * rr * ecc;
      const x = cx + x0 * Math.cos(rot) - y0 * Math.sin(rot), y = cy + x0 * Math.sin(rot) + y0 * Math.cos(rot);
      pts.push([x, y]);
    }
    // smooth closed curve: quadratic segments through the midpoints
    const mid = (a, b) => [(a[0] + b[0]) / 2, (a[1] + b[1]) / 2];
    const f = (p) => p[0].toFixed(0) + ' ' + p[1].toFixed(0);
    let d = 'M' + f(mid(pts[39], pts[0]));
    for (let i = 0; i < 40; i++) d += 'Q' + f(pts[i]) + ' ' + f(mid(pts[i], pts[(i + 1) % 40]));
    paths += `<path d="${d}Z"/>`;
  }
}
const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${W} ${H}" preserveAspectRatio="xMidYMid slice"><g fill="none" stroke="#000" stroke-width="1.1" stroke-opacity=".07">${paths}</g></svg>`;
writeFileSync(process.argv[2], svg);
console.log('texture', (svg.length / 1024).toFixed(0) + ' KB');
