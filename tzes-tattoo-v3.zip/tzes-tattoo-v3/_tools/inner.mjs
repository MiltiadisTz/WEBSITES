// Inner pages: Gallery, About, Contact, Privacy and 404. Called from build.mjs with the page helpers.
const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
const mark = (s, cls) => esc(s).replace(/\*(.+?)\*/g, `<span class="${cls}">$1</span>`);

export function innerPages({ t, b, href, ph, icon, band, ticker }) {
  const c = t.contact;

  // every inner page opens the same way: tag, big headline, lead, and a sticker that drifts with the mouse
  const intro = ({ title, lead, art, tag, word }) => `
<section class="tz-intro${art ? '' : ' tz-intro--plain'}${word ? ' tz-intro--word' : ''}" data-scene="intro" aria-labelledby="tz-intro-title">
  <div class="tz-intro__stage">
    <span class="tz-slash tz-slash--f" aria-hidden="true"></span>
    <span class="tz-cross tz-cross--1" aria-hidden="true"></span><span class="tz-cross tz-cross--2" aria-hidden="true"></span>
    ${word ? `<p class="tz-intro__word" aria-hidden="true">${esc(word)}</p>` : ''}
    <div class="tz-intro__copy">
      <span class="tz-tag" data-scramble>${esc(tag || t.hero.tagPlace)}</span>
      <h1 class="tz-intro__title" id="tz-intro-title" data-split>${mark(title, 'tz-red')}</h1>
      <p class="tz-intro__lead">${esc(lead)}</p>
    </div>
    ${art ? `<div class="tz-intro__art"><img class="tz-intro__img" src="${b}assets/img/cut/${art}-sticker-420.webp" width="420" height="600" alt="" fetchpriority="high"></div>` : ''}
  </div>
</section>`;

  const gallery = () => {
    const g = t.gallery;
    const used = Object.keys(g.styles).filter((k) => g.items.some((x) => x.style === k));
    const count = (k) => g.items.filter((x) => x.style === k).length;
    return `${intro({ title: g.title, lead: g.lead, art: 'eye', tag: `${g.items.length} ${t.lang === 'el' ? 'σχέδια' : 'designs'}` })}
<section class="tz-gal" aria-label="${esc(t.ui.flashLabel)}">
  <div class="tz-wrap">
    <div class="tz-gal__bar" role="group" aria-label="${esc(t.ui.filterLabel)}">
      <button class="tz-chip" type="button" data-filter="all" aria-pressed="true">${esc(t.ui.all)}<span class="tz-chip__n">${g.items.length}</span></button>
      ${used.map((k) => `<button class="tz-chip" type="button" data-filter="${k}" aria-pressed="false">${esc(g.styles[k])}<span class="tz-chip__n">${count(k)}</span></button>`).join('')}
    </div>
    <p class="tz-gal__note">${ph(g.placeholder)}</p>
    <ul class="tz-gal__grid" data-gallery>
      ${g.items.map((x, i) => `<li class="tz-gal__item" data-style="${x.style}">
        <button class="tz-gal__card" type="button" data-open="${i}" data-full="${b}assets/img/works/story-${x.img}-1080.webp" data-name="${esc(x.name)}" data-label="${esc(g.styles[x.style])}" data-cursor="${esc(t.ui.view)}" data-tilt aria-label="${esc(t.ui.open)}: ${esc(x.name)}">
          <span class="tz-gal__frame tz-cut"><img class="tz-gal__img" src="${b}assets/img/works/story-${x.img}-540.webp" width="540" height="960" alt="${esc(x.alt)}" loading="lazy" decoding="async"></span>
          <span class="tz-gal__meta"><span class="tz-gal__style">${esc(g.styles[x.style])}</span><span class="tz-gal__name">${esc(x.name)}</span></span>
        </button>
      </li>`).join('')}
    </ul>
  </div>
</section>
<dialog class="tz-viewer" data-viewer aria-label="${esc(t.ui.lightbox)}">
  <div class="tz-viewer__inner">
    <figure class="tz-viewer__fig tz-cut tz-cut--lg"><img class="tz-viewer__img" data-viewer-img src="${b}assets/img/works/story-${g.items[0].img}-1080.webp" width="1080" height="1920" alt=""></figure>
    <div class="tz-viewer__bar">
      <span class="tz-tag" data-viewer-style></span>
      <p class="tz-viewer__name" data-viewer-name></p>
      <span class="tz-viewer__count" data-viewer-count></span>
      <div class="tz-viewer__nav">
        <button class="tz-viewer__btn" type="button" data-viewer-prev>${icon('arrow-left')}<span class="tz-sr-only">${esc(t.ui.prev)}</span></button>
        <button class="tz-viewer__btn" type="button" data-viewer-next>${icon('arrow-right')}<span class="tz-sr-only">${esc(t.ui.next)}</span></button>
        <button class="tz-viewer__btn tz-viewer__btn--close" type="button" data-viewer-close>${icon('x')}<span class="tz-sr-only">${esc(t.ui.close)}</span></button>
      </div>
    </div>
  </div>
</dialog>
${band(g.band, 'heart')}`;
  };

  const about = () => {
    const a = t.about;
    return `${intro({ title: a.title, lead: a.lead, art: 'heart' })}
<section class="tz-story" aria-labelledby="tz-story-title">
  <div class="tz-wrap tz-story__grid">
    <div class="tz-story__copy" data-reveal>
      <h2 class="tz-h2" id="tz-story-title" data-split>${mark(a.story.title, 'tz-red')}</h2>
      ${a.story.text.map((p) => `<p class="tz-story__text">${esc(p)}</p>`).join('')}
      <p class="tz-story__text">${ph(a.story.placeholder)}</p>
    </div>
    <div class="tz-story__media" data-reveal>
      <div class="tz-spec__frame tz-cut">
        <video class="tz-spec__video" muted loop playsinline preload="none" poster="${b}assets/img/works/studio-6.webp" aria-label="${esc(t.hero.video)}" data-autoplay>
          <source src="${b}assets/video/story.webm" type="video/webm">
          <source src="${b}assets/video/story.mp4" type="video/mp4">
        </video>
      </div>
      <span class="tz-tag tz-tag--pin tz-story__pin" data-scramble>${esc(t.spec.tag)}</span>
    </div>
  </div>
</section>
${ticker}
<section class="tz-steps tz-steps--values" aria-labelledby="tz-values-title">
  <div class="tz-wrap">
    <div class="tz-steps__head">
      <h2 class="tz-h2" id="tz-values-title" data-split>${mark(a.values.title, 'tz-red')}</h2>
    </div>
    <ul class="tz-steps__list">
      ${a.values.items.map((x) => `<li class="tz-steps__item tz-cut" data-reveal>
        <span class="tz-steps__icon">${icon(x.icon)}</span>
        <h3 class="tz-steps__title">${esc(x.title)}</h3>
        <p class="tz-steps__desc">${esc(x.text)}</p>
      </li>`).join('')}
    </ul>
  </div>
</section>
<section class="tz-artist" data-theme="dark" aria-labelledby="tz-artist-title">
  <div class="tz-wrap tz-artist__grid">
    <figure class="tz-artist__photo tz-cut tz-cut--lg" data-reveal>
      <img class="tz-artist__img" src="${b}assets/img/works/studio-13.webp" width="360" height="640" alt="${esc(t.trace.cards[5].alt)}" loading="lazy" decoding="async">
      <figcaption class="tz-tag tz-artist__tag">${esc(t.hero.tagPlace)}</figcaption>
    </figure>
    <div class="tz-artist__copy" data-reveal>
      <h2 class="tz-h2" id="tz-artist-title" data-split>${mark(a.artist.title, 'tz-red-soft')}</h2>
      <p class="tz-artist__name">${ph(a.artist.name)}</p>
      <p class="tz-artist__bio">${ph(a.artist.bio)}</p>
      <a class="tz-btn tz-btn--line tz-btn--light" href="${c.instagramHref}" rel="noopener" target="_blank" data-magnetic>${icon('instagram-logo')}<span>${esc(c.instagram)}</span></a>
    </div>
  </div>
</section>
${band(a.band, 'labrys')}`;
  };

  const contact = () => {
    const p = t.contactPage, f = p.form, d = p.details;
    const field = (id, type, label, auto, extra = '') => `<div class="tz-field">
        <label class="tz-field__label" for="tz-${id}">${esc(label)} <span class="tz-field__req">${esc(t.ui.required)}</span></label>
        <input class="tz-field__input" id="tz-${id}" name="${id}" type="${type}" autocomplete="${auto}" required aria-describedby="tz-${id}-err"${extra}>
        <p class="tz-field__err" id="tz-${id}-err" data-err="${esc(f.errors[id])}"></p>
      </div>`;
    return `${intro({ title: p.title, lead: p.lead, art: 'lettering' })}
<section class="tz-contact" aria-label="${esc(f.title)}">
  <div class="tz-wrap tz-contact__grid">
    <div class="tz-contact__form tz-cut tz-cut--lg" data-reveal>
      <form class="tz-form" data-form novalidate>
        <h2 class="tz-contact__title">${esc(f.title)}</h2>
        <div class="tz-form__row">
          ${field('name', 'text', f.name, 'name')}
          ${field('phone', 'tel', f.phone, 'tel', ' inputmode="tel"')}
        </div>
        ${field('email', 'email', f.email, 'email')}
        <div class="tz-field">
          <label class="tz-field__label" for="tz-message">${esc(f.message)} <span class="tz-field__req">${esc(t.ui.required)}</span></label>
          <p class="tz-field__hint" id="tz-message-hint">${esc(f.messageHint)}</p>
          <textarea class="tz-field__input tz-field__input--area" id="tz-message" name="message" rows="5" required aria-describedby="tz-message-hint tz-message-err"></textarea>
          <p class="tz-field__err" id="tz-message-err" data-err="${esc(f.errors.message)}"></p>
        </div>
        <div class="tz-field tz-field--check">
          <input class="tz-check" id="tz-consent" name="consent" type="checkbox" required aria-describedby="tz-consent-err">
          <label class="tz-check__label" for="tz-consent">${esc(f.consent)} <a href="${href('privacy')}">${esc(f.consentLink)}</a>.</label>
          <p class="tz-field__err" id="tz-consent-err" data-err="${esc(f.errors.consent)}"></p>
        </div>
        <button class="tz-btn tz-btn--red tz-form__submit" type="submit" data-magnetic><span>${esc(f.submit)}</span>${icon('arrow-up-right')}</button>
      </form>
      <div class="tz-form__done" data-form-done hidden tabindex="-1">
        <span class="tz-form__done-icon">${icon('check-circle')}</span>
        <h2 class="tz-contact__title">${esc(f.success.title)}</h2>
        <p>${esc(f.success.text)}</p>
      </div>
    </div>
    <aside class="tz-contact__info" data-reveal>
      <h2 class="tz-contact__title tz-contact__title--ink">${esc(d.title)}</h2>
      <dl class="tz-outro__table tz-contact__table">
        <div><dt>${esc(d.phone)}</dt><dd><a href="${c.phoneHref}">${esc(c.phone)}</a></dd></div>
        <div><dt>${esc(d.whatsapp)}</dt><dd><a href="${c.socials[2].href}" rel="noopener" target="_blank">+30 690 000 0000</a></dd></div>
        <div><dt>${esc(d.email)}</dt><dd><a href="mailto:${c.email}">${esc(c.email)}</a></dd></div>
        <div><dt>${esc(d.address)}</dt><dd><a href="${c.mapsUrl}" rel="noopener" target="_blank">${esc(c.street)}, ${esc(c.city)}</a></dd></div>
        <div><dt>${esc(d.hoursTitle)}</dt><dd>${esc(c.hoursShort)}</dd></div>
      </dl>
      <div class="tz-contact__actions">
        <a class="tz-btn tz-btn--line" href="${c.mapsUrl}" rel="noopener" target="_blank" data-magnetic>${icon('map-trifold')}<span>${t.lang === 'el' ? 'Χάρτης' : 'Map'}</span></a>
        ${c.socials.map((x) => `<a class="tz-contact__icon" href="${x.href}" rel="noopener" target="_blank" aria-label="${esc(x.label)}">${icon(x.icon)}</a>`).join('')}
      </div>
      <img class="tz-contact__art" src="${b}assets/img/cut/wave-sticker-420.webp" width="420" height="600" alt="" loading="lazy" decoding="async">
    </aside>
  </div>
</section>`;
  };

  const privacy = () => {
    const p = t.privacyPage;
    return `${intro({ title: p.title, lead: p.lead })}
<section class="tz-legal">
  <div class="tz-wrap tz-legal__list">
    ${p.sections.map((x) => `<article class="tz-legal__item tz-cut" data-reveal>
      <h2 class="tz-legal__title">${esc(x.title)}</h2>
      <p>${x.text.startsWith('PLACEHOLDER') ? ph(x.text) : esc(x.text)}</p>
    </article>`).join('')}
  </div>
</section>`;
  };

  const notfound = () => {
    const n = t.notFound;
    return `${intro({ title: n.title, lead: n.lead, art: 'moth', word: '404' }).replace('</p>\n    </div>', `</p>
      <div class="tz-hero__actions">
        <a class="tz-btn tz-btn--red" href="${href(n.home.page)}" data-magnetic><span>${esc(n.home.label)}</span>${icon('arrow-left')}</a>
        <a class="tz-btn tz-btn--line" href="${href(n.gallery.page)}" data-magnetic><span>${esc(n.gallery.label)}</span></a>
      </div>
    </div>`)}`;
  };

  return { gallery, about, contact, privacy, notfound };
}
