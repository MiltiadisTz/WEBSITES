# Tzes Tattoo v3 "Ink HUD": manifest

All pages in Greek and English, 24 October 2026 (Home approved 18:39Z; logo and colours to be changed later). Built after the TikTok reference (@prismawebdesign, "SSED") with the studio's own black, white and red. The v2 site stays untouched in `/mnt/project-files/tzes-tattoo/`.

Preview: https://claude.ai/artifact/1xHLqirVvETN6oNoa1DHcc (built with `node _tools/build.mjs --preview`, entry `_entry.html` plus `p-gallery.html`, `p-about.html`, `p-contact.html`, `p-privacy.html`, `p-notfound.html`, each with CSS, JS, fonts and icons inlined; photos, frames and video published next to them).

## Look
- Paper `#e6e2dc` with a fingerprint contour texture (`_tools/texture.mjs`), ink `#0d0c0c` panels, red `#9f0102` with a red gradient for slashes, buttons and highlight tags.
- Type: Roboto Flex at weight 950 to 1000 and width 151% for headlines (subset with Greek, `assets/fonts/tz-flex-*.woff2`), JetBrains Mono for the small HUD tags. Both self-hosted, OFL.
- Cut-corner shapes everywhere (`.tz-cut`), chevron slashes, crosshairs, mono tags.
- Flash art: transparent cut-outs and die-cut sticker versions made from the v2 flash sheets (`_tools/cut.py`, `_tools/sticker.py`).

## Sections and motion
1. Preloader: labrys spins, counter 0 to 100, panel wipes up (once per visit).
2. Hero: giant TZES behind the labrys sticker, outline copy in front, mouse parallax; on scroll the word grows and blurs and the sticker lifts. Studio video card bottom right.
3. Studio card: dark card rises over the hero, red highlight words, studio video.
4. Two crossing tickers (place and styles) that speed up with scroll.
5. Stages: pinned, scroll or tap Sketch / Lines / Shading / Colour to scrub the flash film; tags pop per stage.
6. Works: pinned sideways gallery of 8 pieces with style names, progress bar (swipe row on phones).
7. Take apart: 8 stickers burst out of a pile into a ring around "Every style. One hand.", each links to its style in the gallery.
8. Trace: studio stills and flash cards fly in and stack over "Every skin keeps a story."
9. Steps + aftercare strip, FAQ with review placeholder, ending panel with contact table and a red TZES, footer.
- Custom cursor with labels, magnetic buttons, text scramble on tags, word-by-word heading reveal. Reduced motion turns all of it off.

## Inner pages (`_tools/inner.mjs`)
| Page | Greek | English | What is on it |
|---|---|---|---|
| Gallery | `/galeri/` | `/en/gallery/` | intro with eye sticker, sticky style filter (also from `#style` links on Home), 15 designs, design viewer with arrows, keys and swipe, card tilt |
| About | `/sxetika/` | `/en/about/` | story with studio video, tickers, 4 values, artist panel (studio still, name and bio placeholders), closing band |
| Contact | `/epikoinonia/` | `/en/contact/` | form with field checks and thank-you note, contact table, map and socials |
| Privacy | `/aporrito/` | `/en/privacy/` | 5 placeholder sections |
| 404 | `/404.html` | `/en/404.html` | outline 404 behind the moth sticker, two buttons, noindex |

The contact form has no mail endpoint yet: it checks the fields and shows the thank-you note. Hook it to the studio's email (or the WordPress form) before launch.

## Open
- Placeholders as before: review, deposit, age, minimum price, real contact details. Instagram set to @tzes_tattoo.
- Logo and colours: the user will change them later.
