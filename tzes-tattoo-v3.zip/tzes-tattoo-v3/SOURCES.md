# Sources
- Fonts: Roboto Flex (Google, OFL 1.1) and JetBrains Mono (JetBrains, OFL 1.1) from the @fontsource-variable npm packages, instanced and subset with fontTools. Licences in `assets/fonts/`.
- Icons: Phosphor (MIT), sprite reused from v2.
- Flash art, film frames and gallery images: drawn in code for v2 (`/mnt/project-files/tzes-tattoo/_tools/`), cut-outs made here.
- Studio video and stills: the studio's own Instagram story (approved for use on 2026-10-22).
- Layout idea: TikTok screen recording by @prismawebdesign (reference only, nothing copied).
